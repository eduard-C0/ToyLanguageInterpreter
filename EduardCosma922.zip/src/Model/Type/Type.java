package Model.Type;

import Model.ValueType.Value;

public interface Type {

    String toString();
    Value defaultValue();
}
