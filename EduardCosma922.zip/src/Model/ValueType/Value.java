package Model.ValueType;
import Model.Type.Type;

public interface Value {
    Type getType();
}
