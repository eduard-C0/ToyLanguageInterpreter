package Exception;

public class ExpressionException extends MyIException {
    public ExpressionException(String message){
        super(message);
    }
}
