package Exception;

public class ADTException extends MyIException{
    public ADTException(String message){
        super(message);
    }
}


