package Exception;

public class StmtException extends MyIException {
    public StmtException(String message)
    {
        super(message);
    }
}
